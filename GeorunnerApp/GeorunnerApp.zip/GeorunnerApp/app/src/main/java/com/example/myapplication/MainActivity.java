package com.example.myapplication;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.Menu;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;


import org.osmdroid.bonuspack.kml.KmlDocument;
import org.osmdroid.bonuspack.kml.KmlFeature;
import org.osmdroid.bonuspack.kml.KmlLineString;
import org.osmdroid.bonuspack.kml.KmlPlacemark;
import org.osmdroid.bonuspack.kml.KmlPoint;
import org.osmdroid.bonuspack.kml.KmlPolygon;
import org.osmdroid.bonuspack.kml.KmlTrack;
import org.osmdroid.config.Configuration;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.util.BoundingBox;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.FolderOverlay;
import org.osmdroid.views.overlay.Marker;
import org.osmdroid.views.overlay.Overlay;
import org.osmdroid.views.overlay.Polygon;
import org.osmdroid.views.overlay.Polyline;


import java.io.InputStream;

public class MainActivity extends AppCompatActivity {
    MapView map = null;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //load/initialize the osmdroid configuration, this can be done
        Context ctx = getApplicationContext();
        Configuration.getInstance().load(ctx, PreferenceManager.getDefaultSharedPreferences(ctx));
        Configuration.getInstance().setUserAgentValue(BuildConfig.APPLICATION_ID);

        setContentView(R.layout.activity_main);

        Toolbar myToolbar = findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        map = findViewById(R.id.map);
        map.setTileSource(TileSourceFactory.MAPNIK);

        map.getController().setZoom(3);



    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        KmlDocument kmlDocument = new KmlDocument();
        InputStream kmlStream;
        FolderOverlay kmlOverlay;
        BoundingBox bb;
        KmlFeature.Styler styler = new MyKmlStyler();

        switch (item.getItemId()) {
            case R.id.route1:
                kmlStream = getApplicationContext().getResources().openRawResource(R.raw.t041119);
                kmlDocument.parseKMLStream(kmlStream, null);
                kmlOverlay = (FolderOverlay)kmlDocument.mKmlRoot.buildOverlay(map, null, styler, kmlDocument);

                map.getOverlays().add(kmlOverlay);
                map.invalidate();
                bb = kmlDocument.mKmlRoot.getBoundingBox();
                map.zoomToBoundingBox(bb, true);
                return true;

            case R.id.route2:
                kmlStream = getApplicationContext().getResources().openRawResource(R.raw.data2);
                kmlDocument.parseKMLStream(kmlStream, null);
                kmlOverlay = (FolderOverlay)kmlDocument.mKmlRoot.buildOverlay(map, null, styler, kmlDocument);

                map.getOverlays().add(kmlOverlay);
                map.invalidate();
                bb = kmlDocument.mKmlRoot.getBoundingBox();
                map.zoomToBoundingBox(bb, true);
                return true;

            case R.id.route3:
                kmlStream = getApplicationContext().getResources().openRawResource(R.raw.data3);
                kmlDocument.parseKMLStream(kmlStream, null);
                kmlOverlay = (FolderOverlay)kmlDocument.mKmlRoot.buildOverlay(map, null, styler, kmlDocument);

                map.getOverlays().add(kmlOverlay);
                map.invalidate();
                bb = kmlDocument.mKmlRoot.getBoundingBox();
                map.zoomToBoundingBox(bb, true);
                return true;

            case R.id.clear:
                map.getOverlays().clear();
                map.invalidate();
                return true;

            case R.id.logout:
                finish();

                return true;

            default:
                // If we got here, the user's action was not recognized.
                // Invoke the superclass to handle it.
                return super.onOptionsItemSelected(item);

        }
    }

    public void onResume(){
        super.onResume();
        //this will refresh the osmdroid configuration on resuming.
        //if you make changes to the configuration, use
        //SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        //Configuration.getInstance().load(this, PreferenceManager.getDefaultSharedPreferences(this));
        map.onResume(); //needed for compass, my location overlays, v6.0.0 and up
    }

    public void onPause(){
        super.onPause();
        //this will refresh the osmdroid configuration on resuming.
        //if you make changes to the configuration, use
        //SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        //Configuration.getInstance().save(this, prefs);
        map.onPause();  //needed for compass, my location overlays, v6.0.0 and up
    }
}

class MyKmlStyler implements KmlFeature.Styler {

    @Override
    public void onFeature(Overlay overlay, KmlFeature kmlFeature) {
    }

    @Override
    public void onPoint(Marker marker, KmlPlacemark kmlPlacemark, KmlPoint kmlPoint) {
    }

    @Override
    public void onLineString(Polyline polyline, KmlPlacemark kmlPlacemark, KmlLineString kmlLineString){
        polyline.setWidth(3.0f);
        polyline.setColor(Color.RED);
    }

    @Override
    public void onPolygon(Polygon polygon, KmlPlacemark kmlPlacemark, KmlPolygon kmlPolygon) {
    }

    @Override
    public void onTrack(Polyline polyline, KmlPlacemark kmlPlacemark, KmlTrack kmlTrack) {
    }


}